# GodOfPlayer AI — V2

Browserbasierter Prototyp einer eigenen KI-Oberfläche mit GodOfPlayer-Branding.

## Enthalten
- GPT-6 Astra, GPT-6 Sol, GPT-6 Luna Auswahl
- OpenAI Responses API
- Websuche per `web_search`
- Bildgenerierung per `image_generation` + GPT Image 2.5 Flare
- Bild- und Textdatei-Anhänge
- Browser-Spracherkennung
- lokale Chat-Historie
- Reasoning-Auswahl
- mobile-first Dark UI
- Quellenanzeige bei Websuche

## Start auf Chromebook / Replit / lokal

1. Node.js installieren oder eine Node-Umgebung wie Replit verwenden.
2. `npm install`
3. `.env.example` nach `.env` kopieren und `OPENAI_API_KEY` eintragen.
4. `npm start`
5. Browser auf `http://localhost:3000` öffnen.

Der API-Key gehört ausschließlich ins Backend und niemals in `index.html` oder `app.js`.

## Wichtig
Die Anwendung ist eine eigene Oberfläche mit OpenAI-Modellen. Sie ist keine Kopie der internen ChatGPT-Infrastruktur. Weitere Module wie Login, echte persistente Datenbank, Benutzer-Memory, PDF-Extraktion, Realtime-Voice, Abrechnung und Agent-/Computer-Use-Orchestrierung können auf dieser Basis ergänzt werden.
