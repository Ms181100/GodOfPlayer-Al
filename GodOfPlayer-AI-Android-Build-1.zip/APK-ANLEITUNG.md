# GodOfPlayer AI – APK über das Handy bauen

1. Lege diesen Ordner als eigenes GitHub-Repository an.
2. Lade alle Dateien hoch und pushe auf `main`.
3. Öffne auf GitHub den Tab **Actions**.
4. Wähle **Build GodOfPlayer AI APK**.
5. Tippe **Run workflow**.
6. Nach erfolgreichem Lauf findest du unter dem Workflow das Artefakt `GodOfPlayer-AI-debug`.
7. ZIP des Artefakts öffnen und `app-debug.apk` auf Android installieren.

## Wichtig
Die APK enthält absichtlich keinen OpenAI-API-Key. Für echte KI-Anfragen muss `server.js` auf einem HTTPS-Backend laufen und die App muss auf dessen `/api/chat`-Adresse zeigen. Niemals einen geheimen OpenAI-Key in `app.js` oder in eine öffentlich hochgeladene APK schreiben.
