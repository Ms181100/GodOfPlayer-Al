const messagesEl = document.getElementById("messages");
const input = document.getElementById("input");
const composer = document.getElementById("composer");
const model = document.getElementById("model");
const fileInput = document.getElementById("file");
const filePreview = document.getElementById("filePreview");
const chatList = document.getElementById("chatList");
const status = document.getElementById("status");
const webToggle = document.getElementById("webToggle");
const imageToggle = document.getElementById("imageToggle");
const reasoning = document.getElementById("reasoning");

let attached = [];
let conversation = [];
let chats = JSON.parse(localStorage.getItem("gop-chats") || "[]");

const escapeHtml = (s) => s.replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#039;"}[c]));

function setStatus(text, busy = false) {
  status.textContent = text;
  status.classList.toggle("busy", busy);
}

function renderMessage(role, text, sources = [], image = null) {
  const row = document.createElement("div");
  row.className = `msg ${role}`;
  const bubble = document.createElement("div");
  bubble.className = "bubble";
  bubble.innerHTML = `<div class="msgtext">${escapeHtml(text).replace(/\n/g, "<br>")}</div>`;
  if (image) {
    const img = document.createElement("img");
    img.className = "generated-image";
    img.src = `data:image/png;base64,${image}`;
    img.alt = "Von GodOfPlayer erzeugtes Bild";
    bubble.appendChild(img);
  }
  if (sources.length) {
    const sourceBox = document.createElement("div");
    sourceBox.className = "sources";
    sourceBox.innerHTML = `<b>Quellen</b>${sources.map(s => `<a href="${s.url}" target="_blank" rel="noopener">${escapeHtml(s.title)}</a>`).join("")}`;
    bubble.appendChild(sourceBox);
  }
  row.innerHTML = `<div class="avatar">${role === "user" ? "👤" : "G"}</div>`;
  row.appendChild(bubble);
  messagesEl.appendChild(row);
  messagesEl.scrollTop = messagesEl.scrollHeight;
  return row;
}

function renderChatList() {
  chatList.innerHTML = chats.slice(-20).reverse().map((c, i) =>
    `<button class="chatitem" data-id="${c.id}">💬 ${escapeHtml(c.title)}</button>`
  ).join("");
  chatList.querySelectorAll(".chatitem").forEach(btn => btn.onclick = () => loadChat(btn.dataset.id));
}

function saveCurrentChat() {
  if (!conversation.length) return;
  const first = conversation.find(m => m.role === "user");
  const title = first?.content?.[0]?.text?.slice(0, 42) || "Neuer Chat";
  const id = crypto.randomUUID();
  chats.push({ id, title, messages: conversation });
  chats = chats.slice(-50);
  localStorage.setItem("gop-chats", JSON.stringify(chats));
  renderChatList();
}

function loadChat(id) {
  const c = chats.find(x => x.id === id);
  if (!c) return;
  conversation = c.messages;
  messagesEl.innerHTML = "";
  for (const m of conversation) {
    if (m.role === "user" || m.role === "assistant") {
      const text = Array.isArray(m.content) ? m.content.filter(x => x.type === "input_text" || x.type === "output_text").map(x => x.text).join("\n") : m.content;
      renderMessage(m.role, text);
    }
  }
}

async function readAttachments() {
  const results = [];
  for (const f of attached) {
    if (f.type.startsWith("image/")) {
      const dataUrl = await new Promise((resolve, reject) => {
        const r = new FileReader(); r.onload = () => resolve(r.result); r.onerror = reject; r.readAsDataURL(f);
      });
      results.push({ type: "input_image", image_url: dataUrl });
    } else {
      const text = await f.text();
      results.push({ type: "input_text", text: `Datei: ${f.name}\n\n${text.slice(0, 100000)}` });
    }
  }
  return results;
}

async function sendMessage(text) {
  document.querySelector(".welcome")?.remove();
  renderMessage("user", text);
  input.value = "";
  setStatus("GodOfPlayer denkt…", true);

  const attachmentContent = await readAttachments();
  const userContent = [{ type: "input_text", text }, ...attachmentContent];
  conversation.push({ role: "user", content: userContent });

  const pending = renderMessage("assistant", "…");
  try {
    const apiBase = (localStorage.getItem("gop-api-base") || "").replace(/\/$/, "");
    const response = await fetch(`${apiBase}/api/chat`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        model: model.value,
        messages: conversation,
        web: webToggle.checked,
        image: imageToggle.checked,
        reasoning: reasoning.value
      })
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Serverfehler");
    pending.remove();
    renderMessage("assistant", data.text || "Fertig.", data.sources || [], data.image);
    conversation.push({ role: "assistant", content: [{ type: "output_text", text: data.text || "" }] });
    setStatus("Bereit");
    attached = [];
    fileInput.value = "";
    filePreview.innerHTML = "";
  } catch (err) {
    pending.remove();
    renderMessage("assistant", `Fehler: ${err.message}`);
    setStatus("Fehler");
  }
}

composer.addEventListener("submit", async (e) => {
  e.preventDefault();
  const text = input.value.trim();
  if (!text) return;
  await sendMessage(text);
});

document.getElementById("newChat").onclick = () => {
  saveCurrentChat();
  conversation = [];
  messagesEl.innerHTML = `<div class="welcome"><div class="biglogo">G</div><h1>Was möchtest du machen?</h1><p>GodOfPlayer AI · Chat · Web · Dateien · Bilder · Coding · Voice</p><div class="suggestions"><button>💻 Schreibe mir ein Programm</button><button>📄 Analysiere eine Datei</button><button>🌐 Recherchiere ein Thema</button><button>💡 Entwickle eine Idee mit mir</button></div></div>`;
  bindSuggestions();
  setStatus("Bereit");
};

document.getElementById("attach").onclick = () => fileInput.click();
fileInput.onchange = () => {
  attached = [...fileInput.files];
  filePreview.innerHTML = attached.map(f => `<span class="filetag">📎 ${escapeHtml(f.name)}</span>`).join("");
};

document.getElementById("webBtn").onclick = () => { webToggle.checked = !webToggle.checked; webToggle.dispatchEvent(new Event("change")); };
document.getElementById("imageBtn").onclick = () => { imageToggle.checked = !imageToggle.checked; imageToggle.dispatchEvent(new Event("change")); };
webToggle.onchange = () => document.getElementById("webLabel").classList.toggle("active", webToggle.checked);
imageToggle.onchange = () => document.getElementById("imageLabel").classList.toggle("active", imageToggle.checked);

document.getElementById("voiceBtn").onclick = () => {
  const R = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!R) return alert("Spracherkennung wird in diesem Browser nicht unterstützt.");
  const r = new R(); r.lang = "de-DE"; r.interimResults = false;
  r.onresult = e => { input.value = e.results[0][0].transcript; input.focus(); };
  r.start();
};

input.addEventListener("keydown", e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); composer.requestSubmit(); } });

function bindSuggestions() {
  document.querySelectorAll(".suggestions button").forEach(b => b.onclick = () => { input.value = b.textContent.replace(/^.\s/, ""); input.focus(); });
}
bindSuggestions();
renderChatList();
setStatus("Bereit");
