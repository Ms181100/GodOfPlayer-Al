import express from "express";
import cors from "cors";
import OpenAI from "openai";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const port = process.env.PORT || 3000;

if (!process.env.OPENAI_API_KEY) {
  console.warn("WARNUNG: OPENAI_API_KEY ist nicht gesetzt.");
}

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

app.use(cors());
app.use(express.json({ limit: "25mb" }));
app.use(express.static(__dirname));

function collectSources(response) {
  const sources = [];
  for (const item of response.output || []) {
    for (const content of item.content || []) {
      for (const ann of content.annotations || []) {
        if (ann.type === "url_citation" && ann.url) {
          sources.push({ title: ann.title || ann.url, url: ann.url });
        }
      }
    }
  }
  return [...new Map(sources.map(s => [s.url, s])).values()];
}

app.post("/api/chat", async (req, res) => {
  try {
    const {
      model = "gpt-6-astra",
      messages = [],
      web = false,
      image = false,
      reasoning = "medium"
    } = req.body;

    if (!process.env.OPENAI_API_KEY) {
      return res.status(500).json({ error: "OPENAI_API_KEY fehlt. Lege den API-Schlüssel als Umgebungsvariable fest." });
    }

    const safeModel = ["gpt-6-astra", "gpt-6-sol", "gpt-6-luna"].includes(model)
      ? model
      : "gpt-6-astra";

    const tools = [];
    if (web) tools.push({ type: "web_search" });
    if (image) tools.push({
      type: "image_generation",
      model: "gpt-image-2.5-flare"
    });

    const params = {
      model: safeModel,
      input: messages,
      reasoning: { effort: safeModel === "gpt-6-astra" ? reasoning : reasoning === "xhigh" ? "high" : reasoning },
      tools
    };

    const response = await client.responses.create(params);
    let generatedImage = null;

    for (const item of response.output || []) {
      if (item.type === "image_generation_call" && item.result) {
        generatedImage = item.result;
        break;
      }
    }

    res.json({
      text: response.output_text || "",
      sources: collectSources(response),
      image: generatedImage,
      responseId: response.id
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err?.message || "Unbekannter API-Fehler" });
  }
});

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, apiKeyConfigured: Boolean(process.env.OPENAI_API_KEY) });
});

app.listen(port, () => {
  console.log(`GodOfPlayer AI läuft auf http://localhost:${port}`);
});
